<?php
$MESS["IPOLapiship_PVZ_LIST_HEADER"] = "Доставка в пункты самовывоза";

$MESS["IPOLapiship_COST_FROM"] = "от";
$MESS["IPOLapiship_CURRENCY_RUB"] = "&nbsp;руб.";

$MESS["IPOLapiship_PICKUP"] = "Самовывоз:";
$MESS["IPOLapiship_NO_DELIV"] = "Нет доставки.";

$MESS["IPOLapiship_BALOON_DELIVERY_TERMS"] = "Стоимость и срок доставки";
$MESS["IPOLapiship_BALOON_DELIVERY_COST"] = "Стоимость доставки: ";
$MESS["IPOLapiship_BALOON_DELIVERY_DAYS"] = "Срок доставки: ";

$MESS["IPOLapiship_BALOON_F_PVZ"]      = "Пункт выдачи";
$MESS["IPOLapiship_BALOON_F_POSTAMAT"] = "Постамат";
$MESS["IPOLapiship_BALOON_F_POST"]     = "Отделение Почты";
$MESS["IPOLapiship_BALOON_F_TERMINAL"] = "Терминал";

$MESS["IPOLapiship_BALOON_F_COD"]    = "Оплата при получении";
$MESS["IPOLapiship_BALOON_F_NO_COD"] = "Нет приема оплаты";

$MESS["IPOLapiship_BALOON_FITTING"] = "Есть примерочная";

$MESS["IPOLapiship_BALOON_PAYMENT_CASH"] = "Возможна оплата наличными";
$MESS["IPOLapiship_BALOON_PAYMENT_CARD"] = "Возможна оплата банковской картой";

$MESS['IPOLapiship_DELIVERY_PERIOD_DAY']  = "день";
$MESS['IPOLapiship_DELIVERY_PERIOD_DAYA'] = "дня";
$MESS['IPOLapiship_DELIVERY_PERIOD_DAYS'] = "дней";

$MESS["IPOLapiship_MESS_CHOOZE_PVZ_TEXT"] = "Выберите пункт самовывоза в блоке \"Доставка\"";