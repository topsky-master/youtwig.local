<?php
/**
 * Настройка административного меню модуля dd_blank_module
 *
 * @author  Dev2Day
 * @since   02/07/2012
 *
 * @link    http://dev2day.net/
 */

/**
 * Подключаем языковой меню
 */
IncludeModuleLangFile(__FILE__);

return array(
    /*'parent_menu'                       =>'global_menu_services',
    'section'                           =>'my_stat_list',
    'sort'                              =>1,
    'url'                               =>'/bitrix/admin/my_stat_list.php',
    'text'                              =>GetMessage('MAIN_MENU_LEARN_LIST'),
    'title'                             =>GetMessage('MAIN_MENU_LEARN_LIST'),
    'module_id'                         =>'my_stat',
    'items_id'                          =>'my_stat_content',
    'skip_chain'                        =>false, */
    /*'items'                           =>array(
        array(
            'sort'                      =>100,
            'url'                       =>'admin_page_inner.php',
            'text'                      =>GetMessage( 'DD_BM_INNER_MENU_ITEM_CONTENT_1' ),
            'title'                     =>GetMessage( 'DD_BM_INNER_MENU_ITEM_CONTENT_1' ),
            'icon'                      =>'dd_blank_module_icon',
            'page_icon'                 =>'dd_blank_module_icon',
            'module_id'                 =>'dd_blank_module',
            'items_id'                  =>'menu_dd_blank_module_content',
            'skip_chain'                =>false,
            'more_url'                  =>array(
            ),
        ),
        array(
            'sort'                      =>200,
            'url'                       =>'admin_page_inner.php',
            'text'                      =>GetMessage( 'DD_BM_INNER_MENU_ITEM_CONTENT_2' ),
            'title'                     =>GetMessage( 'DD_BM_INNER_MENU_ITEM_CONTENT_2' ),
            'icon'                      =>'dd_blank_module_icon',
            'page_icon'                 =>'dd_blank_module_icon',
            'module_id'                 =>'dd_blank_module',
            'items_id'                  =>'menu_dd_blank_module_content',
            'skip_chain'                =>false,
            'more_url'                  =>array(
            ),
        ),
        array(
            'sort'                      =>300,
            'url'                       =>'admin_page_inner.php',
            'text'                      =>GetMessage( 'DD_BM_INNER_MENU_ITEM_CONTENT_3' ),
            'title'                     =>GetMessage( 'DD_BM_INNER_MENU_ITEM_CONTENT_3' ),
            'icon'                      =>'dd_blank_module_icon',
            'page_icon'                 =>'dd_blank_module_icon',
            'module_id'                 =>'dd_blank_module',
            'items_id'                  =>'menu_dd_blank_module_content',
            'skip_chain'                =>false,
            'more_url'                  =>array(
            ),
        ),
    ),*/
);