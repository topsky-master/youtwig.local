<?

$MESS['MY_STAT_INSTALL_NAME']        = "Twig - дополнительные настройки";
$MESS['MY_STAT_INSTALL_DESCRIPTION'] = "Функции и классы. Расширяющие возможности магазина.";
$MESS['MY_STAT_PARTNER_NAME']        = "Youtwig";
$MESS['MY_STAT_PARTNER_URI']         = "http://youtwig.ru/";

?>