<?
$MESS["MAIN_MENU_LEARN_LIST"] = "Результаты обучения";
