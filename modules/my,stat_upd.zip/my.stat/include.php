<?

/*
\Bitrix\Main\Loader::registerAutoLoadClasses(
	"my.stat",
	array(
		"my\\stat\\datatable" => "lib/data.php",
	)
);
*/

